# Robot Asistan
Ekranda yüzen 🤖 robot; yazdığın komutu uygular (örn. "spotify'da lady gaga ara").

GitHub'a yükle -> Actions sekmesi -> "Build APK" -> bitince Artifacts'tan `robot-apk` indir.
APK'yı telefona kurup "İzin ver" -> "Robotu başlat".
