package com.example.robot

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.app.SearchManager
import java.util.Locale

object CommandHandler {

    fun run(ctx: Context, raw: String): String {
        val text = raw.lowercase(Locale("tr"))

        return when {
            "spotify" in text -> {
                val q = extractQuery(text, "spotify")
                if (q.isEmpty()) openApp(ctx, "spotify")
                else launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q)))
                    .setPackage("com.spotify.music"), "Spotify'da \"$q\" aranıyor 🎵")
            }
            "youtube" in text -> {
                val q = extractQuery(text, "youtube")
                if (q.isEmpty()) openApp(ctx, "youtube")
                else launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))),
                    "YouTube'da \"$q\" aranıyor ▶️")
            }
            "harita" in text || "yol tarifi" in text -> {
                val q = extractQuery(text, "haritalar", "harita", "yol tarifi")
                launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))),
                    "Haritada \"$q\" gösteriliyor 🗺️")
            }
            Regex("\\d{7,}").containsMatchIn(text) && ("ara" in text) -> {
                val num = Regex("\\d{7,}").find(text)!!.value
                launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")), "$num çevriliyor 📞")
            }
            text.endsWith(" aç") || text.endsWith(" aç.") || text.startsWith("aç ") -> {
                val name = text.replace("aç", "").trim()
                openApp(ctx, name)
            }
            else -> {
                val q = extractQuery(text, "google", "internette", "ara")
                    .ifEmpty { text }
                launch(ctx, Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))),
                    "Google'da \"$q\" aranıyor 🔍")
            }
        }
    }

    // "spotify'da lady gaga ara" -> "lady gaga"
    private fun extractQuery(text: String, vararg keywords: String): String {
        var t = text
        for (k in keywords) t = t.replace(Regex("$k(['’]?\\w{0,3})?"), " ")
        t = t.replace(Regex("\\b(arat|ara|çal|aç|bul|göster|ve|bana)\\b"), " ")
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale("tr")).contains(name)
        } ?: return "\"$name\" uygulamasını bulamadım 😕"
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)!!
        return launch(ctx, i, "${match.loadLabel(pm)} açılıyor 🚀")
    }

    private fun launch(ctx: Context, i: Intent, ok: String): String = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        ok
    } catch (e: Exception) {
        "Yapamadım: ${e.message}"
    }
}
