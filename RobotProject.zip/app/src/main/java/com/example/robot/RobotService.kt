package com.example.robot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class RobotService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var input: EditText
    private lateinit var reply: TextView
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("robot", "Robot", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "robot")
            .setContentTitle("Robot çalışıyor").setSmallIcon(android.R.drawable.ic_dialog_info).build())

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        buildView()
    }

    private fun buildView() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val robot = TextView(this).apply {
            text = "🤖"; textSize = 36f; gravity = Gravity.CENTER
            setPadding(16, 8, 16, 8)
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            visibility = LinearLayout.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 32f }
        }
        reply = TextView(this).apply { setTextColor(Color.DKGRAY); text = "Komut ver 🙂" }
        input = EditText(this).apply {
            hint = "örn: spotify'da lady gaga ara"
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
            imeOptions = EditorInfo.IME_ACTION_SEND
            isSingleLine = true
            setOnEditorActionListener { _, _, _ ->
                val cmd = text.toString().trim()
                if (cmd.isNotEmpty()) {
                    reply.text = CommandHandler.run(this@RobotService, cmd)
                    setText("")
                    setPanelFocusable(false)
                    panel.visibility = LinearLayout.GONE
                }
                true
            }
        }
        panel.addView(reply); panel.addView(input)
        root.addView(robot); root.addView(panel)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 300 }

        // sürükle + dokununca aç/kapat
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        robot.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    params.x = sx + dx; params.y = sy + dy
                    wm.updateViewLayout(root, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(root, params)
    }

    private fun togglePanel() {
        val open = panel.visibility == LinearLayout.VISIBLE
        panel.visibility = if (open) LinearLayout.GONE else LinearLayout.VISIBLE
        setPanelFocusable(!open)
        if (!open) input.requestFocus()
    }

    private fun setPanelFocusable(on: Boolean) {
        params.flags = if (on) 0 else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        wm.updateViewLayout(root, params)
    }

    override fun onDestroy() {
        wm.removeView(root)
        super.onDestroy()
    }
}
