package com.example.robot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        layout.addView(TextView(this).apply {
            text = "🤖 Robot Asistan\n\n1) Başka uygulamaların üzerinde gösterme iznini ver\n2) Robotu başlat"
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "İzin ver"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        layout.addView(Button(this).apply {
            text = "Robotu başlat"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, RobotService::class.java))
                    finish()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "Robotu durdur"
            setOnClickListener { stopService(Intent(this@MainActivity, RobotService::class.java)) }
        })
        setContentView(layout)
    }
}
